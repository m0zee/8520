<h1>Pak Material</h1>
<h3>Account Verification</h3>
Please <a href="{{ url( '/verifyemail/' . $emailToken ) }}">click here</a> to verify your account. 