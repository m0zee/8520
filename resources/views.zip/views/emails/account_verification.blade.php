 <div id=":l7" class="ii gt "><div id=":l8" class="a3s aXjCH m1626ffc0f6b4be77"><u></u>
<div style="margin:0;padding:0" bgcolor="#F0F0F0" marginwidth="0" marginheight="0">
                <table border="0" width="100%" height="100%" cellpadding="0" cellspacing="0" bgcolor="#F0F0F0">
            <tbody><tr>
                <td align="center" valign="top" bgcolor="#F0F0F0" style="background-color:#f0f0f0">
                    <br>
                    <table border="0" width="600" cellpadding="0" cellspacing="0" class="m_-2891262514161602040container" style="width:800px;max-width:600px">
                        <tbody><tr>
                            <td class="m_-2891262514161602040container-padding m_-2891262514161602040content" align="left" style="padding-left:24px;padding-right:24px;padding-top:12px;padding-bottom:12px;background-color:#ffffff">
                                <a href="{{ url('') }}"><img src="{{ asset('images/logo.png') }}" alt="PakMaterial" width="263"></a>
                                <br>
                                <br>
                                <div class="m_-2891262514161602040body-text" style="font-family:Helvetica,Arial,sans-serif;font-size:14px;line-height:20px;text-align:left;color:#333333">
    <p>Greetings form <span class="il">Pakmaterial</span>.com!!!</p>
    <p>Your email id is yet to activate with <span class="il">pakmaterial</span>.</p>
    <p>To make your profile activate and viewed by global audience please do click the below link.</p>
    <p style="text-align:center;margin:10px 0!important">
        <a style="display:inline-block;text-decoration:none;text-align:center;background:#2196f3;color:#fff;padding:10px 20px;border-radius:20px" href="{{ url( '/verifyemail/' . $emailToken ) }}" target="_blank">
            Activate your account
        </a> 
    </p>
    <p>If you have any queries feel free to <a href="{{ url('contact') }}" target="_blank"> contact us </a>.</p>
    <p style="margin-top:10px;margin-bottom:5px">Regards,</p>
    <p><span class="il">Pakmaterial</span> Support.</p>
                                </div>
                            </td>
                        </tr>
                    </tbody></table>
                </td>
            </tr>
        </tbody></table><div class="yj6qo"></div><div class="adL">
    </div></div><div class="adL">


</div></div></div>